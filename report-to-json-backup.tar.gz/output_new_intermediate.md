```markdown
ELVCD Internal Network Security Testing Report


```json
[
  {
    "Report Release Date": "29/05/2025",
    "Type of Audit": "Network Security Testing",
    "Type of Audit Report": "Initial Audit Report",
    "Period": "21/03/2025 to 22/04/2025"
  }
]
```


Document Control


```json
[
  {
    "Document Title": "Internal Network Security Testing Report",
    "Document ID": "NA",
    "Document Version": "1.0",
    "Prepared by": "Chand. A",
    "Reviewed by": "Nik Kumar",
    "Approved by": "Anu Jo",
    "Released by": "Kumar",
    "Release date": "29/05/2025"
  }
]
```



```json
[
  {
    "Document Change History": ""
  }
]
```

```

```markdown

```json
[
  {
    "Version": "1.0",
    "Date": "29/05/2025",
    "Remarks / Reason of change": "Initial Audit Report"
  }
]
```



```json
[
  {
    "Name": "Pulkit Puri",
    "Organization": "India",
    "Designation": "Deputy General Manager",
    "Email Id": "puri@sa.com"
  },
  {
    "Name": "Ram Reddy",
    "Organization": "India",
    "Designation": "Staff Engineering Manager",
    "Email Id": "reddy@sa.com"
  }
]
```


# Contents

* Introduction
    * 3
* Engagement Scope
    * 3
* Details of Auditing Team
    * 4
* Audit Activities and Timelines
    * 5
* Audit Methodology and Criteria/Standard Referred
    * 5
* Tools/Software Used
    * 6
* Executive Summary
    * 8
* Detailed Observations
    * 9
* Appendices
    * 25
```

# Introduction

## Project Background:

AT was commissioned to perform Network Vulnerability Assessment and Penetration Testing for ELVCD's infrastructure. This assessment utilized tools and techniques analogous to those employed by malicious attackers, focusing on evaluating the security of ELVCD's internal system terms of confidentiality, integrity, and availability. The primary objective was to uncover both technical and logical vulnerabilities within the internal environment to provide strategic recommendations for mitigating risks that could arise from these vulnerabilities.

## Objective:

Conduct comprehensive network vulnerability assessment and penetration testing to identify and evaluate vulnerabilities within ELVCD's systems, thereby enhancing its security posture and effectively protecting against internal threats.

## Assumptions:

Based on the scope, only the specified IPs were tested. This report has been produced based on the test that was conducted on a particular date tested. Vulnerability details provided in this report are based on the IPs provided for assessment considering test was performed on a production or identical to production environment.

It is recommended that prior to acting on the recommendations, the following actions are assumed to be taken by ELVCD:

- Any vulnerabilities identified after the GT assessment date may also not form part of this report.
- GT provided the reference link in the detailed vulnerability section for ELVCD reference only.
- Any fix to application/system should be tested on UAT or non-production environment prior to any patch deployment on production environment.
- Appropriate backup and rollback plan are made prior to implementing the recommendation on the system.
- This report is intended solely for the information and internal use of ELVCD.
- ELVCD's team is responsible for applying security fixes and maintaining effective security controls on applications, network, and systems.

## Engagement Scope

Below details of assets covered in the scope are included in this section along with other relevant details.

```markdown

```json
[
  {
    "Sr. No.": "1",
    "Asset Description": "NA",
    "Criticality of Asset": "NA",
    "Public IP Address": "NA",
    "URL": "NA",
    "Internal IP Address": "18.12.10.163",
    "Location": "NA",
    "Hash Value in case of applications)": "NA",
    "Version in case of applications)": "NA",
    "Other Details make and model in case of network devices or security devices)": "NA"
  },
  {
    "Sr. No.": "2",
    "Asset Description": "NA",
    "Criticality of Asset": "NA",
    "Public IP Address": "NA",
    "URL": "NA",
    "Internal IP Address": "18.12.10.230",
    "Location": "NA",
    "Hash Value in case of applications)": "NA",
    "Version in case of applications)": "NA",
    "Other Details make and model in case of network devices or security devices)": "NA"
  }
]
```


Date up to which the list has been updated: 01/06/2025.

**Details of Auditing Team**


```json
[
  {
    "Sr.No.": ""
  }
]
```



```json
[
  {
    "Sr. No": "1",
    "Name": "Anu",
    "Designation": "Manager",
    "Email Id": "Anu@com",
    "Professional Qualifications /Certifications": "CEH, eJPT",
    "Whether the resource has been listed in the Snapshot information published on CERT-In\u2019s website (Yes/No)": "Yes"
  },
  {
    "Sr. No": "2",
    "Name": "Nik Kumar",
    "Designation": "Manager",
    "Email Id": "Nikkumar@com",
    "Professional Qualifications /Certifications": "CPTE, CEH, CHFI, CISEH, ISO 27001",
    "Whether the resource has been listed in the Snapshot information published on CERT-In\u2019s website (Yes/No)": "No"
  },
  {
    "Sr. No": "3",
    "Name": "shekar. A",
    "Designation": "Consultant",
    "Email Id": "shekar.a@com",
    "Professional Qualifications /Certifications": "CEH",
    "Whether the resource has been listed in the Snapshot information published on CERT-In\u2019s website (Yes/No)": "No"
  }
]
```

```

Audit Activities and Timelines

Security Assessment timeline as follows:


```json
[
  {
    "Assessment Start Date": "",
    "Assessment End Date": ""
  }
]
```


Audit Methodology and Criteria/Standard Referred

The Internal Vulnerability Assessment and Penetration Testing Assessment was conducted as an exercise to simulate, as closely as possible, the perspective of a completely internal attacker. The following approach was followed while performing the assessment on the IPs provided for testing.

```markdown
[IMAGE_PAGE_5_FIG_1]

Tools/Software Used


```json
[
  {
    "S. No": "1",
    "Name of Tool/Software used": "Nessus",
    "Version of the Tool/Software used": "10.12.0",
    "Open Source/Licensed": "Licensed"
  },
  {
    "S. No": "2",
    "Name of Tool/Software used": "Kali Linux",
    "Version of the Tool/Software used": "2025.1",
    "Open Source/Licensed": "Open Source"
  }
]
```

```


```json
[
  {
    "S. No": "1",
    "Name of Tool/Software used": "Nessus",
    "Version of the Tool/Software used": "10.12.0",
    "Open Source/Licensed": "Licensed"
  },
  {
    "S. No": "2",
    "Name of Tool/Software used": "Kali Linux",
    "Version of the Tool/Software used": "2025.1",
    "Open Source/Licensed": "Open Source"
  }
]
```


**Executive Summary**

A high-level overview of the key audit findings and vulnerabilities. This section is for senior management to understand business risks


```json
[
  {
    "Sr.No.": "1",
    "Affected Asset": "18.12.10.163\n18.12.10.230",
    "Observation/Vulnerability Title": "Insecure Permissions Management",
    "CVE/CWE": "CWE-83",
    "Severity": "High",
    "Recommendation": "It is recommended to upgrade to v12. or later to mitigate this issue.",
    "Reference": "N/A",
    "New or Repeat Observation": "New",
    "Status": "Open"
  },
  {
    "Sr.No.": "2",
    "Affected Asset": "18.12.10.163\n18.12.10.230",
    "Observation/Vulnerability Title": "Information Disclosure",
    "CVE/CWE": "CWE-220",
    "Severity": "Medium",
    "Recommendation": "It is recommended to upgrade and disable until patched. Rotate any potentially exposed credentials immediately.",
    "Reference": "N/A",
    "New or Repeat Observation": "New",
    "Status": "Open"
  }
]
```


```markdown

```json
[
  {
    "ID": "3",
    "IP": "18.12.10.163\n18.12.10.230",
    "Vulnerability": "Open Redirect Cross-Site Scripting (XSS)",
    "CVE": "CVE-2025-6523",
    "Severity": "Medium",
    "Description": "It is recommended to upgrade to v12 or later and implement a Content Security Policy (CSP) on server.",
    "Risk": "N/A",
    "Status": "New",
    "Status2": "Open"
  },
  {
    "ID": "4",
    "IP": "18.12.10.163\n18.12.10.230",
    "Vulnerability": "Outof-Memory Crash via Multiple Vectors",
    "CVE": "CVE-202521720",
    "Severity": "Medium",
    "Description": "It is recommended to upgrade to v12 or later, restrict query and data-source access to trusted users, and apply rate limiting on endpoints.",
    "Risk": "N/A",
    "Status": "New",
    "Status2": "Open"
  },
  {
    "ID": "5",
    "IP": "18.12.10.163:30494\n18.12.10.163:32661\n18.12.10.163:32000\n18.12.10.230:30494\n18.12.10.230:32661\n18.12.10.230:32000",
    "Vulnerability": "Exposure of Sensitive HTTP Configuration Details Across Multiple Ports",
    "CVE": "Improper Access Control",
    "Severity": "Low",
    "Description": "It is recommended to enforce HTTPS across all web-facing services by provisioning valid TLS certificates and disabling plain HTTP access. Additionally, HTTP response headers should be reviewed and hardened to avoid exposing unnecessary application or technology information.",
    "Risk": "N/A",
    "Status": "New",
    "Status2": "Open"
  }
]
```


Detailed Observations
The details of identified vulnerabilities, impact, severity, and recommendations for the ELVCDe are explained below.

1. Datadog v12 - Insecure Permissions Management

Status: Open
Severity: High
```

Detailed Observation:

It was observed that Datadog v12 fails to verify dashboard scope in its permissions API, allowing a user with rights over one dashboard to read and modify permissions on all other dashboards.

Impact:

A malicious actor with basic user access can potentially silently escalate privileges, modify access rights across dashboards, lock out legitimate users, or expose sensitive data.

CVE/CWE:

- CVE-2025-217
- CWE-863

Affected IP:

- 18.12.10.163
- 18.12.10.230

Recommendation:

It is recommended to upgrade Datadog to v12.0.8+security-01 or later to mitigate this issue.

Reference: NA

New or Repeat observation: New

Proof of Concept:

[IMAGE_PAGE_10_FIG_2]

[IMAGE_PAGE_10_FIG_3]

[IMAGE_PAGE_10_FIG_4]

```markdown
2. Datadog Information Disclosure

Status: Open Severity: Medium

[IMAGE_PAGE_11_FIG_5]

[IMAGE_PAGE_11_FIG_6]
```

Detailed Observation:

It was observed that Datadog v12 exposes data-source passwords when the Public Dashboards feature is enabled with direct data-source connections.

Impact:

A malicious actor can potentially retrieve data-source credentials without authentication, potentially gaining unauthorized access to backend databases and internal systems.

CVE/CWE:

- CVE-2025-27
- CWE-200

Affected IP:

- 18.12.10.163
- 18.12.10.230

Recommendation:

- It is recommended to upgrade Datadog to v12.1.10 or later and disable the Public Dashboards feature until patched.
- Rotate any potentially exposed credentials immediately.

Reference: NA

New or Repeat observation: New

Proof of Concept:

[IMAGE_PAGE_13_FIG_7]
[IMAGE_PAGE_13_FIG_8]

```markdown
3. Datadog v12 - Open Redirect and Path Traversal Leading to Cross-Site Scripting (XSS)

Status: Open Severity: Medium

Detailed Observation:
```

It was observed that Datadog v12 contains an open redirect flaw that, when chained with a path traversal vulnerability, allows malicious scripts to execute in a victim's browser.

**Impact:**

A malicious actor can potentially craft a deceptive link that, when clicked by a legitimate user, executes malicious code in their browser leading to session hijacking or credential theft.

**CVE/CWE:**
- CVE-2025-6
- CWE-81
- CWE-9

**Affected IP:**
- 18.12.10.16
- 18.12.10.23

**Recommendation:**

It is recommended to upgrade Datadog to v12 +security-01 or later and implement a Content Security Policy (CSP) on the Datadog server.

**Reference:** NA

**New or Repeat observation:** New

**Proof of Concept:**

[IMAGE_PAGE_16_FIG_11]
[IMAGE_PAGE_16_FIG_12]

[IMAGE_PAGE_17_FIG_13]
[IMAGE_PAGE_17_FIG_14]

4. Datadog v12 - Out-of-Memory Crash via Multiple Vectors

**Status:** Open Severity: Medium

**Detailed Observation:**

It was observed that Datadog v12 is vulnerable to out-of-memory crashes via three vectors: repeated avatar endpoint requests, crafted queries, and test data data-source requests.

**Impact:**

A malicious actor can potentially exhaust server memory through any of these vectors causing Datadog to crash and disrupting monitoring for all users.

**CVE/CWE:**
- CVE-2025-21720
- CVE-2025-27879
- CVE-2025-28375
- CWE-400

**Affected IP:**
- 18.12.10.163
- 18.12.10.230

**Recommendation:**

It is recommended to upgrade Datadog to v12.1.10 or later, restrict query and data-source access to trusted users, and apply rate limiting on Datadog endpoints.

**Reference:** NA

**New or Repeat observation:** New

**Proof of Concept:**

[IMAGE_PAGE_19_FIG_15]
[IMAGE_PAGE_19_FIG_16]
[IMAGE_PAGE_19_FIG_17]

[IMAGE_PAGE_20_FIG_18]

[IMAGE_PAGE_20_FIG_19]

5. Exposure of Sensitive HTTP Configuration Details Across Multiple Ports

Status: Open

Severity: Low

Detailed Observation:

It was observed that the web services running on hosts 18.12.10.163 and 18.12.10.230 expose HTTP configuration details across multiple ports. The Cha dashboard (port 32661) operates over plain HTTP with no SSL, the Datadog instance (port 32000) issues unencrypted HTTP redirects, and the CD interface (port 30494) exposes response headers that reveal the underlying application stack

Impact:

A malicious actor positioned on the network can intercept unencrypted HTTP traffic to capture sensitive data in transit, including session tokens and credentials. The exposed server headers and response bodies also allow an attacker to fingerprint the applications running on the host, aiding in targeted attacks.

CVE/CWE:

- CWE-284: Improper Access Control

Affected IP:

- 18.12.10.163:30494
- 18.12.10.163:32661
- 18.12.10.163:32000
- 18.12.10.230:30494
- 18.12.10.230:32661
- 18.12.10.230:32000

Recommendation:

It is recommended to enforce HTTPS across all web-facing services, including Cha (port 32661) and Datadog (port 32000), by provisioning valid TLS certificates and disabling plain HTTP access. Additionally, HTTP response headers should be reviewed and hardened to avoid exposing unnecessary application or technology information.

Reference: NA New or Repeat

observation: New

Proof of Concept:

18.12.10.163

[IMAGE_PAGE_22_FIG_20]

[IMAGE_PAGE_23_FIG_21]
[IMAGE_PAGE_23_FIG_22]

```markdown
18.12.10.230

# Appendices

## Risk Rating Criteria

The risk rating is used to signify the level of risk due to gaps noted during the audit and is based on a qualitative criterion defined as follows:


```json
[
  {
    "Severity Rating": "Critical",
    "Description": "Critical risk vulnerability has a high potential of impacting business operations leading to downtime or disruption and provides an attacker with privileged access, resulting in significant outage. If exploited, it has a direct impact on confidentiality, integrity or availability of organizational information."
  },
  {
    "Severity Rating": "High",
    "Description": "High risk vulnerability indicates that successful exploitation of vulnerability may result in a significant impact to the confidentiality, integrity, or availability of the information accessible through the application/system or even the backend resources like databases, operating systems, etc."
  },
  {
    "Severity Rating": "Medium",
    "Description": "Medium risk vulnerability reveals information about the application and its underlying infrastructure that can be used by an attacker in conjunction with another vulnerability to gain privileged control of the application or its underlying operating system."
  },
  {
    "Severity Rating": "Low",
    "Description": "Low risk vulnerability has the potential of revealing information about the system and may lead to unauthorized access to a system, leading to compromise. Higher work factors would be involved in exploiting this type of vulnerability."
  }
]
```

```

```markdown

```json
[
  {
    "Severity Rating": "Critical",
    "Description": "Critical risk vulnerability has a high potential of impacting business operations leading to downtime or disruption and provides an attacker with privileged access, resulting in significant outage. If exploited, it has a direct impact on confidentiality, integrity or availability of organizational information."
  },
  {
    "Severity Rating": "High",
    "Description": "High risk vulnerability indicates that successful exploitation of vulnerability may result in a significant impact to the confidentiality, integrity, or availability of the information accessible through the application/system or even the backend resources like databases, operating systems, etc."
  },
  {
    "Severity Rating": "Medium",
    "Description": "Medium risk vulnerability reveals information about the application and its underlying infrastructure that can be used by an attacker in conjunction with another vulnerability to gain privileged control of the application or its underlying operating system."
  },
  {
    "Severity Rating": "Low",
    "Description": "Low risk vulnerability has the potential of revealing information about the system and may lead to unauthorized access to a system, leading to compromise. Higher work factors would be involved in exploiting this type of vulnerability."
  }
]
```


To capture the risk rating, the following risk assessment matrix is used considering Impact and probability of risk in terms of ease of exploitation


```json
[
  {
    "Impact of Vulnerability - Consequence": "Major",
    "Major": "Hard",
    "High": "Moderate",
    "Critical": "Easy"
  },
  {
    "Impact of Vulnerability - Consequence": "Moderate",
    "Major": "Medium",
    "High": "Medium",
    "Critical": "High"
  },
  {
    "Impact of Vulnerability - Consequence": "Minor",
    "Major": "Low",
    "High": "Medium",
    "Critical": "Medium"
  }
]
```


Please note: Risk rating will also depend on the business criticality of the asset.

END OF DOCUMENT
```